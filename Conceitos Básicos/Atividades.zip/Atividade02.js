for(i = 1; i < 7; i++) {
  console.log(i);
}