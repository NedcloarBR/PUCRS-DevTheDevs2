// Modo Preguiça

console.log(`
    *
   ***
  *****
 *******
*********
    *
    *
    * 
`);