var values = [10, 12]; 

console.log(values[0] + values[1]);