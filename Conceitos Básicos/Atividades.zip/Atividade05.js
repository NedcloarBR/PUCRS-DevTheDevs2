var nota1 = 10;
var nota2 = 8;
var nota3 = 7;
var nota4 = 9;

const total = nota1 + nota2 + nota3 + nota4;
const media = total / 4;

console.log(`Total das notas somadas: ${total}\nMédia das notas: ${media}`);