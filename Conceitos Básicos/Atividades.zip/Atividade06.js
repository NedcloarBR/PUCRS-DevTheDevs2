const metros = 25.5;
const centimetros = 25.5 * 10;

console.log(`${metros}m em centímetros: ${centimetros}`);